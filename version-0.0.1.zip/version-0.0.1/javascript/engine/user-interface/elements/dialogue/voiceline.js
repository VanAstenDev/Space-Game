class VoiceLine {
    constructor(position, text, delay) {
        this.position = position; //left or right
        this.text = text; //string
        this.delay = delay;
    }
}